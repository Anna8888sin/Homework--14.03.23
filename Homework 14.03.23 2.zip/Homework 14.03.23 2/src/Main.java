import java.util.Random;

public class Main {
    public static void main(String[] args) {
        Random random = new Random();
        int a = random.nextInt(0,999);
        int b = random.nextInt(0,999);
        int c = random.nextInt(0,999);
        System.out.println("Искомое число 1: " + a);
        System.out.println("Искомое число 2: " + b);
        System.out.println("Искомое число 3: " + c);
        System.out.println();
        System.out.println("Сумма чисел: " + (a+b+c));
        System.out.println();
        System.out.println("Произведение чисел: " + (a*b*c));
    }
}