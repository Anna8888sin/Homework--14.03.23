import java.util.Scanner;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);
        System.out.println("Введите любое трёхзначное число: ");
        int x = scanner.nextInt();
        System.out.println(x/100);
        System.out.println((x/10)%10);
        System.out.println(x%10);
        System.out.println("Спасибо! Вы ввели число " + x);
    }
}